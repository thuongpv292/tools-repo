package com.vtb;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ApiBffApplication {

    public static void main(String[] args) {
        SpringApplication.run(ApiBffApplication.class, args);
    }
}
