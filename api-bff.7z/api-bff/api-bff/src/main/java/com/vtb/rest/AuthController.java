package com.vtb.rest;

import com.vtb.model.request.UserInfo;
import com.vtb.model.response.ResultData;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.*;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.reactive.function.client.WebClient;
import reactor.core.publisher.Mono;

import javax.xml.transform.Result;
import java.util.Map;

@RestController
public class AuthController {
    @Autowired
    private RestTemplate restTemplate;

    @Value("${keycloak.token-uri}")
    private String tokenUri;

    @Value("${keycloak.client-id}")
    private String clientId;

    @Value("${keycloak.client-secret}")
    private String clientSecret;

    private final WebClient webClient = WebClient.builder().build();

//    @PostMapping("/authenticate")
//    public Mono<ResultData> login(@RequestBody UserInfo userInfo) {
//        String bodyValue = "grant_type=password" +
//                "&client_id=" +
//                clientId +
//                "&client_secret=" +
//                clientSecret + "&username=" +
//                userInfo.getUsername() +
//                "&password=" +
//                userInfo.getPassword();
//        ResultData result = new ResultData();
//        result.setMessage("User or password invalid!");
//        result.setStatus(HttpStatus.UNAUTHORIZED);
//        result.setAccessToken("");
//        return webClient.post()
//                .uri(tokenUri)
//                .bodyValue(bodyValue) // Convert StringBuilder to String
//                .retrieve()
//                .bodyToMono(Object.class) // Result is access token
//                .map(resultData -> {
//                    result.setAccessToken(resultData);
//                    result.setMessage("Authenticate successfully!");
//                    result.setStatus(HttpStatus.ACCEPTED);
//                    ResponseEntity.ok(resultData);
//                    System.out.println("Show result data =================");
//                    System.out.println(resultData);
//                    return result;
//                }) // Wrap result in ResponseEntity
//                .onErrorResume(error -> Mono.just(result));
//
//    }


    @PostMapping("/authenticate")
    public ResultData login(@RequestBody UserInfo userInfo) {
        String bodyValue = "grant_type=password" +
                "&client_id=" + clientId +
                "&client_secret=" + clientSecret +
                "&username=" + userInfo.getUsername() +
                "&password=" + userInfo.getPassword();

        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_FORM_URLENCODED);

        HttpEntity<String> request = new HttpEntity<>(bodyValue, headers);

        ResultData result = new ResultData();
        result.setMessage("User or password invalid!");
        result.setStatus(HttpStatus.UNAUTHORIZED);
        result.setAccessToken("");

        try {
            ResponseEntity<Object> response = restTemplate.exchange(tokenUri, HttpMethod.POST, request, Object.class);
            if (response.getStatusCode() == HttpStatus.OK) {
                Object responseBody = response.getBody();
                // Assuming the response body is a JSON object with an access_token field
                // You may need to extract the access token from the response body properly
                String accessToken = extractAccessToken(responseBody);

                result.setAccessToken(accessToken);
                result.setMessage("Authenticate successfully!");
                result.setStatus(HttpStatus.ACCEPTED);
            }
        } catch (Exception e) {
            // Log the exception if necessary
            e.printStackTrace();
        }

        return result;
    }

    // Helper method to extract the access token from the response body
    private String extractAccessToken(Object responseBody) {
        // Implement the logic to extract the access token from the response body
        // This is a placeholder implementation and needs to be replaced
        if (responseBody instanceof Map) {
            Map<String, Object> responseMap = (Map<String, Object>) responseBody;
            return (String) responseMap.get("access_token");
        }
        return "";
    }
}
