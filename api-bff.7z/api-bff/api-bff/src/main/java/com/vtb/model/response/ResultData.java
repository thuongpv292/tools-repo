package com.vtb.model.response;

import lombok.Data;
import org.springframework.http.HttpStatus;


@Data
public class ResultData {
    private Object accessToken;
    private String message;
    private HttpStatus status;
}
