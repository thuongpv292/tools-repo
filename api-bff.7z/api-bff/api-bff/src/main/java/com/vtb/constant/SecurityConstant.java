package com.vtb.constant;

public class SecurityConstant {
    private SecurityConstant(){
        throw new IllegalStateException();
    }
    public static final String RSA_ALGORITHM = "RSA";
}
