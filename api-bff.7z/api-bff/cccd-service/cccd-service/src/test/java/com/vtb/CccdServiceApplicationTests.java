package com.vtb;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CccdServiceApplicationTests {

    @Test
    void contextLoads() {
    }

}
